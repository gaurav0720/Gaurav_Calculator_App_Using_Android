package com.example.mini_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

     EditText edtxtnumbers;
     Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btnallclear,
            btnclear,btndivision,btnmultiply,btndot,btnplus,btnminus,btnequals,btnnegative;

     int  index = 0 ;
    Double  privious_val, current_val , result;
    boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn0 = findViewById(R.id.btn0);
        btn0.setOnClickListener(this);
        btn1 = findViewById(R.id.btn1);
        btn1.setOnClickListener(this);
        btn2 = findViewById(R.id.btn2);
        btn2.setOnClickListener(this);
        btn3 = findViewById(R.id.btn3);
        btn3.setOnClickListener(this);
        btn4 = findViewById(R.id.btn4);
        btn4.setOnClickListener(this);
        btn5= findViewById(R.id.btn5);
        btn5.setOnClickListener(this);
        btn6 = findViewById(R.id.btn6);
        btn6.setOnClickListener(this);
        btn7 = findViewById(R.id.btn7);
        btn7.setOnClickListener(this);
        btn8 = findViewById(R.id.btn8);
        btn8.setOnClickListener(this);
        btn9 = findViewById(R.id.btn9);
        btn9.setOnClickListener(this);

        btnclear = findViewById(R.id.btnclear);
        btnclear.setOnClickListener(this);
        btndivision = findViewById(R.id.btndivision);
        btndivision.setOnClickListener(this);
        btnmultiply = findViewById(R.id.btnmultiply);
        btnmultiply.setOnClickListener(this);
        btnminus = findViewById(R.id.btnminus);
        btnminus.setOnClickListener(this);
        btnplus = findViewById(R.id.btnplus);
        btnplus.setOnClickListener(this);
        btndot = findViewById(R.id.btndot);
        btndot.setOnClickListener(this);

        btnequals = findViewById(R.id.btnequals);
        btnequals.setOnClickListener(this);

        btnallclear = findViewById(R.id.btnallclear);
        btnallclear.setOnClickListener(this);

        btnnegative = findViewById(R.id.btnnegative);
        btnnegative.setOnClickListener(this);

        edtxtnumbers = findViewById(R.id.edtxtnumbers);


    }

    @Override
    public void onClick(View v) {
       switch (v.getId()){
           case R.id.btn0:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"0");
               break;

           case R.id.btn1:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"1");
               break;

           case R.id.btn2:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"2");
               break;
           case R.id.btn3:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"3");
               break;
           case R.id.btn4:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"4");
               break;
           case R.id.btn5:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"5");
               break;
           case R.id.btn6:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"6");
               break;
           case R.id.btn7:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"7");
               break;
           case R.id.btn8:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"8");
               break;
           case R.id.btn9:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"9");
               break;
           case R.id.btndot:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+".");
               break;

           case R.id.btnnegative:
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"-");
               break;

           case R.id.btnplus:
               privious_val = Double.parseDouble(edtxtnumbers.getText().toString() + " ");
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"+");
               index=1;
               flag=true;
               edtxtnumbers.setText(" ");
               break;
           case R.id.btnminus:
               privious_val = Double.parseDouble(edtxtnumbers.getText().toString() + " ");
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"-");
               index=2;
               flag=true;
               edtxtnumbers.setText(" ");
               break;
           case R.id.btnmultiply:
               privious_val = Double.parseDouble(edtxtnumbers.getText().toString() + " ");
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"*");
               index=3;
               flag=true;
               edtxtnumbers.setText(" ");
               break;
           case R.id.btndivision:
               privious_val = Double.parseDouble(edtxtnumbers.getText().toString() + " ");
               edtxtnumbers.setText((edtxtnumbers.getText().toString())+"/");
               index=4;
               flag=true;
               edtxtnumbers.setText(" ");
               break;

           case R.id.btnclear:
               String current_value = edtxtnumbers.getText().toString();
               if (current_value.length() > 0) {
                    edtxtnumbers.setText(current_value.substring(0, (current_value.length() - 1)));
               }
               else{

               }
              break;

           case R.id.btnallclear:
               edtxtnumbers.setText("");
               break;

           case R.id.btnequals:
               if(edtxtnumbers.getText() == null){
                   Toast.makeText(this, "Enter a Value", Toast.LENGTH_SHORT).show();
               }
               else {
                   current_val = Double.parseDouble(edtxtnumbers.getText().toString() + " ");
                   switch (index) {
                       case 1:

                           result = privious_val + current_val;
                           edtxtnumbers.setText(result.toString());

                           break;

                       case 2:

                           result = privious_val - current_val;
                           edtxtnumbers.setText(result.toString());
                           break;

                       case 3:

                           result = privious_val * current_val;
                           edtxtnumbers.setText(result.toString());
                           break;

                       case 4:

                           result = privious_val / current_val;
                           edtxtnumbers.setText(result.toString());
                           break;

                   }
               }
       }

    }
}
